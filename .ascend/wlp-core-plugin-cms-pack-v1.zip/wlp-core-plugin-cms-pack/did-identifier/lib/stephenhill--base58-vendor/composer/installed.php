<?php return array(
    'root' => array(
        'name' => '__root__',
        'pretty_version' => '1.0.0+no-version-set',
        'version' => '1.0.0.0',
        'reference' => null,
        'type' => 'library',
        'install_path' => __DIR__ . '/../../',
        'aliases' => array(),
        'dev' => true,
    ),
    'versions' => array(
        '__root__' => array(
            'pretty_version' => '1.0.0+no-version-set',
            'version' => '1.0.0.0',
            'reference' => null,
            'type' => 'library',
            'install_path' => __DIR__ . '/../../',
            'aliases' => array(),
            'dev_requirement' => false,
        ),
        'stephenhill/base58' => array(
            'pretty_version' => 'v1.1.5',
            'version' => '1.1.5.0',
            'reference' => 'bd9fc19c788160a2f85ba0a19cd800eaf5ba5e99',
            'type' => 'library',
            'install_path' => __DIR__ . '/../stephenhill/base58',
            'aliases' => array(),
            'dev_requirement' => false,
        ),
    ),
);
