<?php return array(
    'root' => array(
        'name' => '__root__',
        'pretty_version' => '1.0.0+no-version-set',
        'version' => '1.0.0.0',
        'reference' => null,
        'type' => 'library',
        'install_path' => __DIR__ . '/../../',
        'aliases' => array(),
        'dev' => true,
    ),
    'versions' => array(
        '__root__' => array(
            'pretty_version' => '1.0.0+no-version-set',
            'version' => '1.0.0.0',
            'reference' => null,
            'type' => 'library',
            'install_path' => __DIR__ . '/../../',
            'aliases' => array(),
            'dev_requirement' => false,
        ),
        'christian-riesen/base32' => array(
            'pretty_version' => '1.6.0',
            'version' => '1.6.0.0',
            'reference' => '2e82dab3baa008e24a505649b0d583c31d31e894',
            'type' => 'library',
            'install_path' => __DIR__ . '/../christian-riesen/base32',
            'aliases' => array(),
            'dev_requirement' => false,
        ),
    ),
);
