<?php
/**
 * Plugin Name: Decentralized Plugins
 * Description: A simple plugin to manage migration and display repository information.
 * Version: 1.8
 * Author: Your Name
 * Author URI: https://yourwebsite.com
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Create admin menu
add_action('admin_menu', 'decentralized_plugins_menu');

function decentralized_plugins_menu() {
    add_menu_page(
        'Decentralized Plugins',
        'Decentralized Plugins',
        'manage_options',
        'decentralized-plugins',
        'decentralized_plugins_page',
        'dashicons-admin-plugins', // WordPress plugins logo
        100
    );
}

// Render the admin page
function decentralized_plugins_page() {
    ?>
    <div class="wrap">
        <h1>Decentralized Plugins</h1>
        
        <div class="tabs">
            <button class="tablink active" onclick="openTab(event, 'cores')">Cores (2)</button>
            <button class="tablink" onclick="openTab(event, 'plugins')">Plugins (4)</button>
            <button class="tablink" onclick="openTab(event, 'themes')">Themes (2)</button>
        </div>

        <div id="cores" class="tabcontent active">
            <div style="background-color: #ffdddd; border-left: 6px solid #f44336; padding: 15px; margin-bottom: 20px;">
                <strong>Warning:</strong> It is recommended that you deactivate all your plugins before migrating.
            </div>
            <table class="core-table" style="width: 100%; border-collapse: collapse;">
                <thead>
                    <tr>
                        <th style="border: 1px solid #ddd; padding: 8px;">Core</th>
                        <th style="border: 1px solid #ddd; padding: 8px;">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td style="border: 1px solid #ddd; padding: 8px;">WhitelabelPress 1.0.0</td>
                        <td style="border: 1px solid #ddd; padding: 8px;">
                            <button id="migrate-whitelabel" class="button button-primary">Migrate to Whitelabel</button>
                        </td>
                    </tr>
                    <tr>
                        <td style="border: 1px solid #ddd; padding: 8px;">WordPress 6.6.2</td>
                        <td style="border: 1px solid #ddd; padding: 8px;">
                            <button id="migrate-wordpress" class="button button-secondary">Migrate to WordPress</button>
                        </td>
                    </tr>
                </tbody>
            </table>
            <div id="migration-result"></div>
        </div>

        <div id="plugins" class="tabcontent">
            <h2>Plugins (0)</h2>
            <p>This section will display the list of plugins.</p>
            <table class="plugin-table" style="width: 100%; border-collapse: collapse;">
                <thead>
                    <tr>
                        <th style="border: 1px solid #ddd; padding: 8px;">Plugin Name</th>
                        <th style="border: 1px solid #ddd; padding: 8px;">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Add rows for plugins here in future implementation -->
                    <tr>
                        <td colspan="2" style="text-align: center; border: 1px solid #ddd; padding: 8px;">No plugins available.</td>
                    </tr>
                </tbody>
            </table>
        </div>

        <div id="themes" class="tabcontent">
            <h2>Themes (0)</h2>
            <p>This section will display the list of themes.</p>
            <table class="theme-table" style="width: 100%; border-collapse: collapse;">
                <thead>
                    <tr>
                        <th style="border: 1px solid #ddd; padding: 8px;">Theme Name</th>
                        <th style="border: 1px solid #ddd; padding: 8px;">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Add rows for themes here in future implementation -->
                    <tr>
                        <td colspan="2" style="text-align: center; border: 1px solid #ddd; padding: 8px;">No themes available.</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

    <script>
        document.getElementById('migrate-whitelabel').addEventListener('click', function() {
            executeMigration('whitelabel');
        });
        document.getElementById('migrate-wordpress').addEventListener('click', function() {
            executeMigration('wordpress');
        });

        function executeMigration(type) {
            const xhr = new XMLHttpRequest();
            xhr.open('POST', ajaxurl, true);
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
            xhr.onload = function() {
                document.getElementById('migration-result').innerHTML = this.responseText;

                // Redirect to the WordPress admin homepage after 1 second
                setTimeout(function() {
                    window.location.href = "<?php echo admin_url(); ?>?nocache=" + new Date().getTime();
                }, 1000); // 1000 milliseconds = 1 second
            };
            xhr.send('action=migrate_' + type);
        }

        function openTab(evt, tabName) {
            // Hide all tab contents
            var tabcontents = document.getElementsByClassName("tabcontent");
            for (var i = 0; i < tabcontents.length; i++) {
                tabcontents[i].style.display = "none";
            }

            // Remove the 'active' class from all tab links
            var tablinks = document.getElementsByClassName("tablink");
            for (var i = 0; i < tablinks.length; i++) {
                tablinks[i].className = tablinks[i].className.replace(" active", "");
            }

            // Show the current tab and add an 'active' class to the link that opened the tab
            document.getElementById(tabName).style.display = "block";
            evt.currentTarget.className += " active";
        }

        // Display the default tab (cores) when the page loads
        document.addEventListener('DOMContentLoaded', function() {
            document.getElementById('cores').style.display = "block";
        });
    </script>
    <style>
        .tabs {
            margin-bottom: 20px;
        }
        .tablink {
            background-color: #f1f1f1;
            border: none;
            outline: none;
            cursor: pointer;
            padding: 14px 16px;
            transition: 0.3s;
            margin-right: 5px;
            font-size: 17px;
        }
        .tablink.active {
            background-color: #ccc;
        }
        .tabcontent {
            display: none;
            padding: 20px;
            border: 1px solid #ddd;
            border-top: none;
        }
    </style>
    <?php
}

// Handle AJAX requests
add_action('wp_ajax_migrate_whitelabel', 'migrate_to_whitelabel');
add_action('wp_ajax_migrate_wordpress', 'migrate_to_wordpress');

function migrate_to_whitelabel() {
    $output = shell_exec('php /home/neil/yoga/mind/scripts/migrate-to-whitelabel.php 2>&1');
    echo nl2br($output);
    wp_die(); // This is required to terminate immediately and return a proper response
}

function migrate_to_wordpress() {
    $output = shell_exec('php /home/neil/yoga/mind/scripts/migrate-to-wordpress.php 2>&1');
    echo nl2br($output);
    wp_die(); // This is required to terminate immediately and return a proper response
}

